/*
 * DIO.c
 *
 * Created: 05-Feb-23 2:12:37 PM
 *  Author: El-Gredly
 */ 

#include <avr/io.h>
#include "../std_macros.h"
#include "DIO.h"

void DIO_vSetPINDir(char portname, uint8_t pinnumber, uint8_t dir)
{
	switch(portname){
		case 'a':
		case 'A':
		if(dir)
		{
			SET_BIT(DDRA,pinnumber);
		}
		else
		{
			CLR_BIT(DDRA,pinnumber);
		}
		break;
		case 'b':
		case 'B':
		if(dir)
		{
			SET_BIT(DDRB,pinnumber);
		}
		else
		{
			CLR_BIT(DDRB,pinnumber);
		}
		break;
		case 'c':
		case 'C':
		if(dir)
		{
			SET_BIT(DDRC,pinnumber);
		}
		else
		{
			CLR_BIT(DDRC,pinnumber);
		}
		break;
		case 'd':
		case 'D':
		if(dir)
		{
			SET_BIT(DDRD,pinnumber);
		}
		else
		{
			CLR_BIT(DDRD,pinnumber);
		}
		break;
	}
}


void DIO_writePIN(char portname, uint8_t pinnumber, uint8_t val)
{
	switch(portname){
		case 'a':
		case 'A':
		if(val)
		{
			SET_BIT(PORTA,pinnumber);
		}
		else
		{
			CLR_BIT(PORTA,pinnumber);
		}
		break;
		case 'b':
		case 'B':
		if(val)
		{
			SET_BIT(PORTB,pinnumber);
		}
		else
		{
			CLR_BIT(PORTB,pinnumber);
		}
		break;
		case 'c':
		case 'C':
		if(val)
		{
			SET_BIT(PORTC,pinnumber);
		}
		else
		{
			CLR_BIT(PORTC,pinnumber);
		}
		break;
		case 'd':
		case 'D':
		if(val)
		{
			SET_BIT(PORTD,pinnumber);
		}
		else
		{
			CLR_BIT(PORTD,pinnumber);
		}
		break;
	}
}



void DIO_togglePIN(char portname, uint8_t pinnumber)
{
	switch(portname){
		case 'a':
		case 'A':
		TOG_BIT(PORTA,pinnumber);
		break;
		case 'b':
		case 'B':
		TOG_BIT(PORTB,pinnumber);
		break;
		case 'c':
		case 'C':
		TOG_BIT(PORTC,pinnumber);
		break;
		case 'd':
		case 'D':
		TOG_BIT(PORTD,pinnumber);
		break;
	}
}



uint8_t DIO_u8read(char portname, uint8_t pinnumber)
{
	uint8_t val=0;
	switch(portname){
		case 'a':
		case 'A':
		val = READ_BIT(PINA,pinnumber);
		break;
		case 'b':
		case 'B':
		val = READ_BIT(PINB,pinnumber);
		break;
		case 'c':
		case 'C':
		val = READ_BIT(PINC,pinnumber);
		break;
		case 'd':
		case 'D':
		val = READ_BIT(PIND,pinnumber);
		break;
	}
	return val;
}


void DIO_vSetPortDir(char portname, uint8_t dir)
{
	
	switch(portname){
		case 'a':
		case 'A':
		DDRA = dir;
		break;
		case 'b':
		case 'B':
		DDRB = dir;
		break;
		case 'c':
		case 'C':
		DDRC = dir;
		break;
		case 'd':
		case 'D':
		DDRD = dir;
		break;
	}
}


void DIO_writePort(char portname, uint8_t val){
	switch(portname){
		case 'a':
		case 'A':
		PORTA = val;
		break;
		case 'b':
		case 'B':
		PORTB = val;
		break;
		case 'c':
		case 'C':
		PORTC = val;
		break;
		case 'd':
		case 'D':
		PORTD = val;
		break;
	}
}


uint8_t DIO_u8readPort(char portname)
{
	uint8_t val=0 ;
	switch(portname){
		case 'a':
		case 'A':
		val = PINA;
		break;
		case 'b':
		case 'B':
		val = PINB;
		break;
		case 'c':
		case 'C':
		val = PINC;
		break;
		case 'd':
		case 'D':
		val = PIND;
		break;
	}
	return val;
}



void DIO_togglePort(char portname)
{
	switch(portname){
		case 'a':
		case 'A':
		PORTA = ~PORTA;
		break;
		case 'b':
		case 'B':
		PORTB = ~PORTB;
		break;
		case 'c':
		case 'C':
		PORTC = ~PORTC;
		break;
		case 'd':
		case 'D':
		PORTD = ~PORTD;
		break;
	}
}
void DIO_enable_pull_up(char portname, uint8_t pinnumber, uint8_t enable){
	switch(portname){
		case 'a':
		case 'A':
			if(enable)
			{
				SET_BIT(PORTA,pinnumber);
			}else{
				CLR_BIT(PINA,pinnumber);
			}
		break;
		case 'b':
		case 'B':
		if(enable)
		{
			SET_BIT(PORTB,pinnumber);
			}else{
			CLR_BIT(PINB,pinnumber);
		}
		break;
		case 'c':
		case 'C':
		if(enable)
		{
			SET_BIT(PORTC,pinnumber);
			}else{
			CLR_BIT(PINC,pinnumber);
		}
		break;
		case 'd':
		case 'D':
		if(enable)
		{
			SET_BIT(PORTD,pinnumber);
			}else{
			CLR_BIT(PIND,pinnumber);
		}
		break;
	}
}


void DIO_write_low_nibble(uint8_t portname,uint8_t val)
{
	val = val& 0x0f;
	
	switch(portname){
		case 'a':
		case 'A':
			PORTA &= 0xf0 ;
			PORTA|= val;
		break;
		case 'b': 
		case 'B':
			PORTB &= 0xf0 ;
			PORTB|= val;
		break;
		case 'c':
		case 'C':
			PORTC  &= 0xf0 ;
			PORTC|= val;
		break;
		case 'd':
		case 'D':
			PORTD &= 0xf0 ;
			PORTD|= val;
		break;
	}
}


void DIO_write_high_nibble(uint8_t portname,uint8_t val)
{
	val <<=4 ;
	
	switch(portname){
		case 'a':
		case 'A':
		PORTA &= 0x0f ;
		PORTA|= val;
		break;
		case 'b':
		case 'B':
		PORTB &= 0x0f ;
		PORTB|= val;
		break;
		case 'c':
		case 'C':
		PORTC &= 0x0f ;
		PORTC|= val;
		break;
		case 'd':
		case 'D':
		PORTD &= 0x0f ;
		PORTD|= val;
		break;
	}
}

void DIO_vconnectpullup(char portname ,char pinnumber, char connect_pullup)
{
	switch(portname)
	{
		case 'A':
		case 'a':
		if(connect_pullup==1)
		{
			SET_BIT(PORTA,pinnumber);
		}
		else
		{
			CLR_BIT(PORTA,pinnumber);
		}
		break;
		case 'B':
		case 'b':
		if(connect_pullup==1)
		{
			SET_BIT(PORTB,pinnumber);
		}
		else
		{
			CLR_BIT(PORTB,pinnumber);
		}
		break;
		case 'c':
		case 'C':
		if(connect_pullup==1)
		{
			SET_BIT(PORTC,pinnumber);
			
		}
		else
		{
			CLR_BIT(PORTC,pinnumber);
		}
		break;
		case 'd':
		case 'D':
		if(connect_pullup==1)
		{
			SET_BIT(PORTD,pinnumber);
			
		}
		else
		{
			CLR_BIT(PORTD,pinnumber);
		}
		break;
		
	}
}

void DIO_vconnectpullup_port(char portname , char connect_pullup)
{
	switch(portname)
	{
		case 'A':
		case 'a':
		if(connect_pullup==1)
		{
			PORTA = 0xFF ;
		}
		else
		{
			PORTA = 0x00 ;
		}
		break;
		case 'B':
		case 'b':
		if(connect_pullup==1)
		{
			PORTB = 0xFF ;
		}
		else
		{
			PORTB = 0x00 ;
		}
		break;
		case 'c':
		case 'C':
		if(connect_pullup==1)
		{
			PORTC = 0xFF ;
		}
		else
		{
			PORTC = 0x00 ;
		}
		break;
		case 'd':
		case 'D':
		if(connect_pullup==1)
		{
			PORTD = 0xFF ;
		}
		else
		{
			PORTD = 0x00 ;
		}
		break;
		
	}
}