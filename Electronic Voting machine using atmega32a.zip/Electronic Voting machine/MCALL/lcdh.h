/*
 * lcdh.h
 *
 * Created: 26-Feb-23 1:35:24 PM
 *  Author: El-Gredly
 */ 



#include "../MHALL/DIO.h"
#include "lcd_config.h"

#define CLR_SC 0x01
#define CLCD_RS_ON_DIS_ON 0x0E
#define RETURN_HOME 0x02
#define ENTRY_MD 0x06

#if defined _4BITS
#define LCD_PORT 'A'
#define LCD_REG_P 'A'
#define LCD_RS 5
#define LCD_EN 4
#define RW 6
#define FOUR_BITS 0x28
#elif defined _8BITS
#define LCD_PORT 'A'
#define LCD_REG_P 'B'
#define LCD_RS 1
#define LCD_EN 0
#define RW 2
#define  EIGH_BITS 0x38
#endif
static void enable();
void LCD_send_char(char data);
void LCD_send_cmd(char cmd);
void LCD_init();
void LCD_CLR();

void LCD_move_Cursor(uint8_t row, uint8_t col);
void LCD_send_string(char *str);
