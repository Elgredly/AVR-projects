/*
 * btn.c
 *
 * Created: 07-Feb-23 7:17:20 PM
 *  Author: El-Gredly
 */ 
#include "../std_macros.h"
#include <avr/io.h>


void btn_init(char portName, uint8_t pinNumber)
{
	DIO_vSetPINDir(portName,pinNumber,0);
}

uint8_t btn_u8read(char portName, uint8_t pinNumber)
{
	return DIO_u8read(portName,pinNumber);
	
}