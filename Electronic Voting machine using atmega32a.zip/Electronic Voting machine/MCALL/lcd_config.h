/*
 * lcd_config.h
 *
 * Created: 04-Mar-23 1:30:05 PM
 *  Author: El-Gredly
 */ 


#ifndef LCD_CONFIG_H_
#define LCD_CONFIG_H_

#define _4BITS

#endif /* LCD_CONFIG_H_ */