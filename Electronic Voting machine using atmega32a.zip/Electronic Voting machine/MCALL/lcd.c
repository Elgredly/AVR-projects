/*
 * lcd.c
 *
 * Created: 26-Feb-23 1:35:43 PM
 *  Author: El-Gredly
 */ 

#include <avr/io.h>
#define F_CPU 8e6
#include <util/delay.h>
#include "../std_macros.h"
#include "../MHALL/DIO.h"
#define F_CPU 8e6
#include <util/delay.h>
#include "lcdh.h"

void LCD_send_char(char data)
{
	#if defined _8BITS
	DIO_writePort(LCD_PORT,data);
	DIO_writePIN(LCD_REG_P,LCD_RS,1);
	enable();
	
	#elif defined _4BITS
	DIO_write_low_nibble(LCD_PORT,data>>4);
	DIO_writePIN(LCD_REG_P, LCD_RS,1);
	enable();
	DIO_write_low_nibble(LCD_PORT, data);
	DIO_writePIN(LCD_REG_P, LCD_RS,1);
	enable();
	_delay_ms(1);
	#endif
}
void LCD_send_cmd(char cmd)
{
	#if defined _8BITS
	DIO_writePort(LCD_PORT,cmd);
	DIO_writePIN(LCD_REG_P,LCD_RS,0);
	enable(); 
	_delay_ms(1); 
	#elif defined _4BITS
	DIO_write_low_nibble(LCD_PORT,cmd>>4);
	DIO_writePIN(LCD_REG_P, LCD_RS,0);
	enable();
	DIO_write_low_nibble(LCD_PORT, cmd);
	DIO_writePIN(LCD_REG_P, LCD_RS,0);
	enable();
	_delay_ms(1);
	#endif
}

static void enable()
{
	DIO_writePIN(LCD_REG_P,LCD_EN,1);
	_delay_ms(2);
	DIO_writePIN(LCD_REG_P,LCD_EN,0);
	_delay_ms(2);
}

void LCD_CLR()
{
	LCD_send_cmd(0x01);
	_delay_ms(9);
}

void LCD_init(){
	_delay_ms(200);
	#if defined _8BITS
	DIO_vSetPortDir(LCD_PORT,0xFF);
	DIO_vSetPortDir(LCD_REG_P,LCD_EN,1);
	DIO_vSetPortDir(LCD_REG_P,LCD_RS,1);
	DIO_vSetPortDir(LCD_REG_P,RW,1);
	DIO_writePIN(LCD_REG_P,RW,0);
	LCD_send_cmd(EIGH_BITS);
	_delay_ms(1);
	LCD_send_cmd(CLCD_RS_ON_DIS_ON);
	_delay_ms(1);
	LCD_send_cmd(CLR_SC);
	_delay_ms(10);
	LCD_send_cmd(ENTRY_MD);
	_delay_ms(1);
	
	#elif defined _4BITS
	DIO_vSetPortDir(LCD_PORT,0xFF);
	DIO_writePIN(LCD_REG_P,RW,0);
	LCD_send_cmd(RETURN_HOME);
	_delay_ms(10);
	LCD_send_cmd(FOUR_BITS);
	_delay_ms(1);
	LCD_send_cmd(CLCD_RS_ON_DIS_ON);
	_delay_ms(1);
	LCD_send_cmd(CLR_SC);
	_delay_ms(10);
	LCD_send_cmd(ENTRY_MD);
	_delay_ms(1);
	#endif
	_delay_ms(10);
}

void LCD_move_Cursor(uint8_t row, uint8_t col)
{
	uint8_t data;
	if(row >2 || row<1 || col>16 || col<1 )
	{
		data = 0x80;
		
	}
	else if (row == 1 ) 
	{
		data = 0x80 + col - 1;
	}
	else
	{
		data = 0xc0 + col - 1;
	}
	LCD_send_cmd(data);
	_delay_ms(1);
}

void LCD_send_string(char *str)
{
	while(*str !='\0')
	{
		LCD_send_char(*str);
		_delay_ms(20);
		str++;
	}
}



