/*
 * btn.h
 *
 * Created: 07-Feb-23 7:17:35 PM
 *  Author: El-Gredly
 */ 



void btn_init(char portName, uint8_t pinNumber);

uint8_t btn_u8read(char portName, uint8_t pinNumber);