/*
 * Electronic Voting machine.c
 *
 * Created: 11-Mar-23 1:07:49 PM
 * Author : El-Gredly
 */ 

#include <avr/io.h>
#define F_CPU 8e6
#include <util/delay.h>
#include "MHALL/DIO.h"	
#include "MCALL/btn.h"
#include "MCALL/keypad.h"
#include "MCALL/lcdh.h"

void send_digits_to_LCD(unsigned short num, char row, char col )
{
	char str[10];
	signed char i=0;
	while(num)
	{
		str[i]=((num%10)+'0');
		num/=10;
		++i;
	}
	LCD_move_Cursor(row,col);
	for(i=i-1; i>=0; --i )
	{
		LCD_send_char(str[i]);
	}
	
}
void reset()
{
	LCD_CLR();
	LCD_send_string("A=");
	LCD_send_char('0');
	
	LCD_move_Cursor(1,9);
	LCD_send_string("B=");
	LCD_send_char('0');
	
	LCD_move_Cursor(2,1);
	LCD_send_string("C=");
	LCD_send_char('0');
	
	LCD_move_Cursor(2,9);
	LCD_send_string("D=");
	LCD_send_char('0');
}

int main(void)
{
	unsigned short a=0,b=0,c=0,d=0;
	LCD_init();
	for(char i = 0 ; i<5 ; ++i)
	{
		btn_init('C',i);
		//DIO_enable_pull_up('C',i,1);
	}
    /* Replace with your application code */
    reset();
	while (1) 
    {
		if(a==999 || b ==999 || c==999 || d==999)
		{
			LCD_CLR();
			LCD_send_string("OVERFLOW!!!");
			reset();
			a=b=c=d=0;
		}

		else if(btn_u8read('C',0)==1){
			++a;
			send_digits_to_LCD(a,1,3);
			/*LCD_move_Cursor(1,3);
			LCD_send_char(a+'0');*/
			 
		}
		else if(btn_u8read('C',1)==1){
			++b;
			send_digits_to_LCD(b,1,11);

			 
		}
		else if(btn_u8read('C',2)==1){
			++c;
			send_digits_to_LCD(c,2,3);

			 
		}
		else if(btn_u8read('C',3)==1){
			++d;
			send_digits_to_LCD(d,2,11);

			 
		}
		else if(btn_u8read('C',4)==1){
			reset();
			a=b=c=d=0;
			
		}
		else
		{
			continue;
		}
		_delay_ms(100);

    }
}

