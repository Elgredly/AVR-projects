/*
 * DIO.c
 *
 * Created: 05-Feb-23 2:12:37 PM
 *  Author: El-Gredly
 */ 

#include <avr/io.h>
#include "std_macros.h"
#include "DIO.h"

void DIO_vSetPINDir(char portname, uint8_t pinnumber, uint8_t dir)
{
	switch(portname){
		case 'a':
		case 'A':
		if(dir)
		{
			SET_BIT(DDRA,pinnumber);
		}
		else
		{
			CLR_BIT(DDRA,pinnumber);
		}
		break;
		case 'b':
		case 'B':
		if(dir)
		{
			SET_BIT(DDRB,pinnumber);
		}
		else
		{
			CLR_BIT(DDRB,pinnumber);
		}
		break;
		case 'c':
		case 'C':
		if(dir)
		{
			SET_BIT(DDRC,pinnumber);
		}
		else
		{
			CLR_BIT(DDRC,pinnumber);
		}
		break;
		case 'd':
		case 'D':
		if(dir)
		{
			SET_BIT(DDRD,pinnumber);
		}
		else
		{
			CLR_BIT(DDRD,pinnumber);
		}
		break;
	}
}


void DIO_writePIN(char portname, uint8_t pinnumber, uint8_t val)
{
	switch(portname){
		case 'a':
		case 'A':
		if(val)
		{
			SET_BIT(PORTA,pinnumber);
		}
		else
		{
			CLR_BIT(PORTA,pinnumber);
		}
		break;
		case 'b':
		case 'B':
		if(val)
		{
			SET_BIT(PORTB,pinnumber);
		}
		else
		{
			CLR_BIT(PORTB,pinnumber);
		}
		break;
		case 'c':
		case 'C':
		if(val)
		{
			SET_BIT(PORTC,pinnumber);
		}
		else
		{
			CLR_BIT(PORTC,pinnumber);
		}
		break;
		case 'd':
		case 'D':
		if(val)
		{
			SET_BIT(PORTD,pinnumber);
		}
		else
		{
			CLR_BIT(PORTD,pinnumber);
		}
		break;
	}
}



void DIO_togglePIN(char portname, uint8_t pinnumber)
{
	switch(portname){
		case 'a':
		case 'A':
		TOG_BIT(PORTA,pinnumber);
		break;
		case 'b':
		case 'B':
		TOG_BIT(PORTB,pinnumber);
		break;
		case 'c':
		case 'C':
		TOG_BIT(PORTC,pinnumber);
		break;
		case 'd':
		case 'D':
		TOG_BIT(PORTD,pinnumber);
		break;
	}
}



uint8_t DIO_u8read(char portname, uint8_t pinnumber)
{
	uint8_t val=0;
	switch(portname){
		case 'a':
		case 'A':
		val = READ_BIT(PINA,pinnumber);
		break;
		case 'b':
		case 'B':
		val = READ_BIT(PINB,pinnumber);
		break;
		case 'c':
		case 'C':
		val = READ_BIT(PINC,pinnumber);
		break;
		case 'd':
		case 'D':
		val = READ_BIT(PIND,pinnumber);
		break;
	}
	return val;
}


void DIO_vSetPortDir(char portname, uint8_t dir)
{
	switch(portname){
		case 'a':
		case 'A':
		DDRA = dir;
		break;
		case 'b':
		case 'B':
		DDRB = dir;
		break;
		case 'c':
		case 'C':
		DDRC = dir;
		break;
		case 'd':
		case 'D':
		DDRD = dir;
		break;
	}
}


void DIO_writePort(char portname, uint8_t val){
	val*=11111111;
	switch(portname){
		case 'a':
		case 'A':
		PORTA = val;
		break;
		case 'b':
		case 'B':
		PORTB = val;
		break;
		case 'c':
		case 'C':
		PORTC = val;
		break;
		case 'd':
		case 'D':
		PORTD = val;
		break;
	}
}


uint8_t DIO_u8readPort(char portname)
{
	uint8_t val=0 ;
	switch(portname){
		case 'a':
		case 'A':
		val = PINA;
		break;
		case 'b':
		case 'B':
		val = PINB;
		break;
		case 'c':
		case 'C':
		val = PINC;
		break;
		case 'd':
		case 'D':
		val = PIND;
		break;
	}
	return val;
}



void DIO_togglePort(char portname)
{
	switch(portname){
		case 'a':
		case 'A':
		PORTA = ~PORTA;
		break;
		case 'b':
		case 'B':
		PORTB = ~PORTB;
		break;
		case 'c':
		case 'C':
		PORTC = ~PORTC;
		break;
		case 'd':
		case 'D':
		PORTD = ~PORTD;
		break;
	}
}
