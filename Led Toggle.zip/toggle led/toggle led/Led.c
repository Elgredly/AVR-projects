/*
 * Led.c
 *
 * Created: 03-Feb-23 11:00:58 AM
 *  Author: El-Gredly
 */ 
#include <avr/io.h>
#include "std_macros.h"
#define F_CPU 8e6
#include <util/delay.h>
#include "Led.h"
#include "DIO.h"

void led_init(char portName, signed char pinNumber){
	DIO_vSetPINDir(portName, pinNumber, 1);
}

void led_on(char portName, signed char pinNumber){
	DIO_writePIN(portName, pinNumber, 1);
}

void led_off(char portName, signed char pinNumber){
	DIO_writePIN(portName, pinNumber, 0);
}

void led_toggle(char portName, signed char pinNumber){
	DIO_togglePIN(portName,pinNumber);
}

uint8_t led_read_status(char portName, signed char pinNumber){
	return DIO_u8read(portName,pinNumber);
}