/*
 * Led.h
 *
 * Created: 03-Feb-23 11:01:11 AM
 *  Author: El-Gredly
 */ 


#ifndef LED_H_
#define LED_H_


void led_init(char portName, signed char pinNumber);
void led_on(char portName, signed char pinNumber);

void led_off(char portName, signed char pinNumber);

void led_toggle(char portName, signed char pinNumber);

uint8_t led_read_status(char portName, signed char pinNumber);


#endif /* LED_H_ */