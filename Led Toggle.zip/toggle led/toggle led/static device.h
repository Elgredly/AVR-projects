/*
 * static_device.h
 *
 * Created: 05-Feb-23 2:24:11 PM
 *  Author: El-Gredly
 */ 


void Dev_init(char portName, signed char pinNumber);
void Dev_on(char portName, signed char pinNumber);

void Dev_off(char portName, signed char pinNumber);

void Dev_toggle(char portName, signed char pinNumber);

uint8_t Dev_read_status(char portName, signed char pinNumber);



