/*
 * static_device.c
 *
 * Created: 05-Feb-23 2:24:03 PM
 *  Author: El-Gredly
 */ 
#include <avr/io.h>
#include "std_macros.h"
#define F_CPU 8e6
#include <util/delay.h>
#include "static device.h"
#include "DIO.h"

void Dev_init(char portName, signed char pinNumber){
	DIO_vSetPINDir(portName, pinNumber, 1);
}

void Dev_on(char portName, signed char pinNumber){
	DIO_writePIN(portName, pinNumber, 1);
}

void Dev_off(char portName, signed char pinNumber){
	DIO_writePIN(portName, pinNumber, 0);
}

void Dev_toggle(char portName, signed char pinNumber){
	DIO_togglePIN(portName,pinNumber);
}

uint8_t Dev_read_status(char portName, signed char pinNumber){
	return DIO_u8read(portName,pinNumber);
}
