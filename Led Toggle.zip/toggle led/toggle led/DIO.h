/*
 * DIO.h
 *
 * Created: 05-Feb-23 2:12:52 PM
 *  Author: El-Gredly
 */ 



void DIO_vSetPINDir( char portname, unsigned char pinnumber, unsigned char dir);
void DIO_writePIN( char portname, unsigned char pinnumber, unsigned char val);
void DIO_togglePIN(char portname, uint8_t pinnumber);
uint8_t DIO_u8read(char portname, uint8_t pinnumbeer);

void DIO_vSetPortDir(char portname, uint8_t dir);
void DIO_writePort(char portname, uint8_t val);
uint8_t DIO_u8readPort(char portname);
void DIO_togglePort(char portname);