/*
 * GccApplication1.c
 *
 * Created: 12-Jan-23 12:16:18 PM
 * Author : El-Gredly
 */ 

#include <avr/io.h>
#include "std_micros.h"
#define  F_CPU 8000000UL
#include <util/delay.h>
#include "DIO.h"
#include "static device.h"
#define DELAY_MS(x) for(uint32_t i = 0 ; i<x ; ++i) _delay_ms(1);


void Devth_sec(){
	
		//solution with %
		for(uint8_t i = 1 ; i<=8 ;++i){
			Dev_toggle('a',0);
			if(i%2==0){
				 Dev_toggle('a',1);
			}
			if(i%3==0) {
				Dev_toggle('a',2);
			}
			if(i%4==0) {
				Dev_toggle('a',3);
			}
			if(i%5==0) {
				Dev_toggle('a',4);
			}
			if(i%6==0) {
				Dev_toggle('a',5);
			}
			if(i%7==0) {
				Dev_toggle('a',6);
			}
			if(i%8==0) {
				Dev_toggle('a',7);
			}

			DELAY_MS(1000);
		}
		
		//normal solution 
	/*Dev_off('a',0);
		Dev_off('a',1);
		Dev_off('a',2);
		DELAY_MS(1000UL);
		
		Dev_on('a',0);
		
		DELAY_MS(1000UL);
		
		Dev_off('a',0);
		Dev_on('a',1);
		DELAY_MS(1000UL);
		
		Dev_on('a',0);
		Dev_on('a',2);
		DELAY_MS(1000UL);
		
		Dev_off('a',0);
		Dev_off('a',1);
		DELAY_MS(1000);
		
		Dev_off('a',1);
		Dev_on('a',0);
		DELAY_MS(1000UL);
		
		Dev_off('a',0);
		Dev_on('a',1);
		Dev_off('a',2);
		DELAY_MS(1000UL);
		
		Dev_on('a',0);
		Dev_on('a',1);
		DELAY_MS(1000UL);*/
		
		
		
		
}

int main(void)
{
    /* Replace with your application code */
	DIO_vSetPortDir('a',0xff);
	DIO_vSetPortDir('b',0x00);
	DIO_vSetPortDir('c',0x00);
	DIO_vSetPortDir('d',0x00);
	
	while (1) 
    {
		
		Devth_sec();
	}
}

